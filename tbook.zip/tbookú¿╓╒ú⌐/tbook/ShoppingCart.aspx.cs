﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using tbook.Logic;
using tbook.Models;

namespace tbook
{
    public partial class ShoppingCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (ShoppingCartActions usersShoppingCart = new ShoppingCartActions())
            {
                decimal cartTotal = 0;
                cartTotal = usersShoppingCart.GetTotal();
                if (cartTotal > 0)
                {
                    // 显示购物车商品总价
                    lblTotal.Text = String.Format("{0:c}", cartTotal);
                }
                else
                {
                    lblTotalText.Text = "";
                    lblTotal.Text = "";
                    ShoppingCartTitle.InnerText = "购物车是空的";
                }
            }
        }
        public List<CartItem> GetShoppingCartItems()
        {
            ShoppingCartActions actions = new ShoppingCartActions();
            return actions.GetCartItems();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Response.Redirect("Checkout/Checkout.aspx");
        }
    }
}