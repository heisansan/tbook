﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using tbook.Models;

namespace tbook.Logic
{
    public class BookActions
    {
        //对实体类的CRUD应放DataAccess文件夹,Logic只做与业务相关的处理,
        //如检查书是否已存在,下单前检查是否量够等,但快速开发
        //讲求实效,故忽略.各位可按需求再行分层改写.
        //另,因实体对象在各层都可触及,页面可以实体类,如Book送到Logic
        //添加图书,尚需处理书已存在情况(未开发)
        public bool AddBook(string BookName, string Author, string Publiser, string
       Description, string UnitPrice, string Category, string ImagePath)
        {
            var book = new Book();
            book.BookName = BookName;
            book.Author = Author;
            book.Publisher = Publiser;
            book.Description = Description;
            book.UnitPrice = Convert.ToDouble(UnitPrice);
            book.CategoryID = Convert.ToInt32(Category);
            book.ImagePath = ImagePath;
            //添加图书时库存设0,要增加自修改图书
            book.Quantity = 0;
            using (UboContext _db = new UboContext())
            {
                // 添加图书到数据库.
                _db.Books.Add(book);
                _db.SaveChanges();
            }
            // 成功
            return true;
        }
        //删除图书
        public bool RemoveBook(int? bookID)
        {
            bool result = false;
            if (bookID == null)
            {
                return false;
            }
            using (var _db = new tbook.Models.UboContext())
            {
                //int bookId = Convert.ToInt16(ddlRemoveBook.SelectedValue);
                var myItem = (from c in _db.Books
                              where c.BookID == bookID
                              select c).FirstOrDefault();
                if (myItem != null)
                {
                    _db.Books.Remove(myItem);
                    _db.SaveChanges();
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            return result;
        }
    }
}
