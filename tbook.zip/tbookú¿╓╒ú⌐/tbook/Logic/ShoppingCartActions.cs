﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using tbook.Models;

namespace tbook.Logic
{
    public class ShoppingCartActions : IDisposable
    {
        public string CartId { get; set; }
        private UboContext _db = new UboContext();
        public const string CartSessionKey = "CartId";
        public void AddToCart(int id)
        {
            // 在DB中找出图书商品 
            CartId = GetCartId();
            var cartItem = _db.CartItems.SingleOrDefault(
            c => c.CartId == CartId
            && c.BookId == id);
            if (cartItem == null)
            {
                // 如果购物车不存在,建一个exists. 
                cartItem = new CartItem
                {
                    ItemId = Guid.NewGuid().ToString(),
                    BookId = id,
                    CartId = CartId,
                    Book = _db.Books.SingleOrDefault(b => b.BookID == id),
                    Quantity = 1,
                    DateCreated = DateTime.Now
                };
                _db.CartItems.Add(cartItem);
            }
            else
            {
                // 商品已在购物车,则+1 
                cartItem.Quantity++;
            }
            _db.SaveChanges();
        }
        public void Dispose()
        {
            if (_db != null)
            {
                _db.Dispose();
                _db = null;
            }
        }
        public string GetCartId()
        {
            if (HttpContext.Current.Session[CartSessionKey] == null)
            {
                if
               (!string.IsNullOrWhiteSpace(HttpContext.Current.User.Identity.Name))
                {
                    HttpContext.Current.Session[CartSessionKey] =
                   HttpContext.Current.User.Identity.Name;
                }
                else
                {
                    // 使用Guid class产生全局唯一的购物车编号 
                    Guid tempCartId = Guid.NewGuid();
                    HttpContext.Current.Session[CartSessionKey] = tempCartId.ToString();
                }
            }
            return HttpContext.Current.Session[CartSessionKey].ToString();
        }
        public List<CartItem> GetCartItems()
        {
            CartId = GetCartId();
            return _db.CartItems.Where(c => c.CartId == CartId).ToList();
        }
        public decimal GetTotal()
        {
            CartId = GetCartId();
            //计算购物车中商品总价 
            decimal? total = decimal.Zero;
            total = (decimal?)(from cartItems in _db.CartItems
                               where cartItems.CartId == CartId
                               select (int?)cartItems.Quantity *
                                cartItems.Book.UnitPrice).Sum();
            return total ?? decimal.Zero;
        }
        public int GetCount()
        {
            CartId = GetCartId();
            // Get the count of each item in the cart and sum them up 
            int? count = (from cartItems in _db.CartItems
                          where cartItems.CartId == CartId
                          select (int?)cartItems.Quantity).Sum();
            // Return 0 if all entries are null 
            return count ?? 0;
        }

    }
}
