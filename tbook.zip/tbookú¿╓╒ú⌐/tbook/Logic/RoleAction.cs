﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using tbook.Models;


namespace tbook.Logic
{
    /*Internal 是访问修饰符，只有同一程序集 (.dll 文件) 中包含的文件内才
    能访问，本例是限缩 RoleActions 类的被访范围。*/
    internal class RoleActions
    {
        internal void AddUserAndRole()
        {
            // 以ApplicationDbContext类建立context对象,并声明两个对象
            Models.ApplicationDbContext context = new ApplicationDbContext();
            IdentityResult IdRoleResult;
            IdentityResult IdUserResult;
            // 透过context对象建立RoleStore对象
            var roleStore = new RoleStore<IdentityRole>(context);
            // 透过RoleStore对象建立roleMgr对象
            var roleMgr = new RoleManager<IdentityRole>(roleStore);
            // 最后,建我们要的角色Manager，如果不存在就建它
            if (!roleMgr.RoleExists("Manager"))
            {
                IdRoleResult = roleMgr.Create(new IdentityRole { Name = "Manager" });
            }
            // 建立一个管理员帐号admin
            var userMgr = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            var appUser = new ApplicationUser
            {
                UserName = "admin",
                Email = "admin@tBookOnline.com"
            };
            //设置默认密码Pa$$1234
            //IdUserResult = userMgr.Create(appUser,ConfigurationManager.AppSettings["AppUserPasswordKey"]);
            IdUserResult = userMgr.Create(appUser, "Pa$$1234");
            // 若admin成功添加,把它加入Manager角色
            //if (!userMgr.IsInRole(userMgr.FindByEmail("admin@tBookOnline.com").Id,"Manager"))
            if (!userMgr.IsInRole(userMgr.FindByName("admin").Id, "Manager"))
            {
                //IdUserResult = userMgr.AddToRole(userMgr.FindByEmail("admin@tBookOnline.com").Id, "Manager");
                IdUserResult = userMgr.AddToRole(userMgr.FindByName("admin").Id, "Manager");
            }
        }
    }
}
