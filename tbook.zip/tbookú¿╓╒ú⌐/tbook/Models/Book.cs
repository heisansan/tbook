﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace tbook.Models
{
    public class Book
    {
        [ScaffoldColumn(false)]
        public int BookID { get; set; }
        [Required, StringLength(100), Display(Name = "书名")]
        public string BookName { get; set; }
        [Required, StringLength(20), Display(Name = "作者")]
        public string Author { get; set; }
        [Required, StringLength(20), Display(Name = "出版")]
        public string Publisher { get; set; }
        [Required, StringLength(300), Display(Name = "说明"), DataType(DataType.MultilineText)]
        public string Description { get; set; }
        public string ImagePath { get; set; }
        [Display(Name = "价格")]
        public double? UnitPrice { get; set; }
        [Required, Display(Name = "数量")]
        public int Quantity { get; set; }
        public int? CategoryID { get; set; }
        public virtual Category Category { get; set; }
    }
}