﻿using System;
using System.Linq;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace tbook.Models
{
    public class Category
    {
        [ScaffoldColumn(false)]
        public int CategoryID { get; set; }
        [Required, StringLength(100), Display(Name = "类名")]
        public string CategoryName { get; set; }
        [Display(Name = "说明")]
        public string Description { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }
}