﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace tbook.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public System.DateTime OrderDate { get; set; }
        public string Username { get; set; }
        [Required(ErrorMessage = "名字是必要的")]
        [DisplayName("名字")]
        [StringLength(160)]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "姓氏是必要的")]
        [DisplayName("姓氏")]
        [StringLength(160)]
        public string LastName { get; set; }
        [Required(ErrorMessage = "地址是必要的")]
        [StringLength(70)]
        public string Address { get; set; }
        [Required(ErrorMessage = "城市是必要的")]
        [StringLength(40)]
        public string City { get; set; }
        [Required(ErrorMessage = "省份是必要的")]
        [StringLength(40)]
        public string State { get; set; }
        [Required(ErrorMessage = "邮编是必要的")]
        [DisplayName("邮编")]
        [StringLength(10)]
        public string PostalCode { get; set; }
        [Required(ErrorMessage = "国名是必要的")]
        [StringLength(40)]
        public string Country { get; set; }
        [StringLength(24)]
        public string Phone { get; set; }
        [Required(ErrorMessage = "邮箱是必要的")]
        [DisplayName("邮箱")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}",
        ErrorMessage = "邮箱输入错误")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [ScaffoldColumn(false)]
        public decimal Total { get; set; }
        [ScaffoldColumn(false)]
        public string PaymentTransactionId { get; set; }
        [ScaffoldColumn(false)]
        public bool HasBeenShipped { get; set; }
        public List<OrderDetail> OrderDetails { get; set; }
    }
}